package com.greenfox.hellobean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellobeanApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellobeanApplication.class, args);
	}
}
